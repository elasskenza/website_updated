---
title: Teaching
layout: page
categories:
  - Markup
elements:
  - content
  - css
  - formatting
  - html
  - markup  
---

# Econometrics of Qualitative Dependent Variables

You can find here the exercises of the Econometrics of Qualitative Dependent Variables course.

<object data="../assets/Plaquette_2020_2021_exo.pdf" width="1000" height="1000" type='application/pdf'></object>
