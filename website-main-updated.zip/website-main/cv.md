---
layout: page
title: "CV"
categories:
  - Markup
elements:
  - content
  - css
  - formatting
  - html
  - markup  
---

<object data="../assets/CV_anglais.pdf" width="1000" height="1000" type='application/pdf'></object>
